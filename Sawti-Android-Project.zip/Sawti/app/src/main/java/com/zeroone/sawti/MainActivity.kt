package com.zeroone.sawti

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 32)
            textDirection = android.view.View.TEXT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = "صوتي"
            textSize = 30f
            setTextColor(0xFF14243A.toInt())
        }
        val description = TextView(this).apply {
            text = "تحويل الكلام العربي إلى نص مباشر، مع نافذة عائمة تعمل فوق التطبيقات."
            textSize = 17f
            setPadding(0, 18, 0, 24)
        }
        val start = Button(this).apply {
            text = "بدء الاستماع العائم"
            setOnClickListener { prepareAndStart() }
        }
        val stop = Button(this).apply {
            text = "إيقاف الاستماع"
            setOnClickListener { stopService(Intent(this@MainActivity, SpeechService::class.java)) }
        }
        val note = TextView(this).apply {
            text = "ملاحظة: يعتمد التعرف الصوتي في هذه النسخة على مزود Speech Recognition المثبت على الهاتف، وقد يحتاج إلى الإنترنت. جودة اللهجة العراقية وسرعة النتائج تختلفان حسب المزود والاتصال."
            textSize = 14f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title); layout.addView(description); layout.addView(start)
        layout.addView(stop); layout.addView(note)
        setContentView(layout)
    }

    private fun prepareAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), requestCode)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح لصوتي بالظهور فوق التطبيقات", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, SpeechService::class.java))
        Toast.makeText(this, "بدأ تشغيل صوتي", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) prepareAndStart()
    }
}
