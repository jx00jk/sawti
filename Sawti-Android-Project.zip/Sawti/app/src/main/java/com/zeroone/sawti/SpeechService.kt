package com.zeroone.sawti

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class SpeechService : Service(), RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var transcript: TextView? = null
    private var status: TextView? = null
    private var finalText = ""
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, buildNotification())
        showOverlay()
        startRecognition()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("sawti_mic", "صوتي - الاستماع",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "sawti_mic") else Notification.Builder(this)
        return builder.setContentTitle("صوتي يعمل")
            .setContentText("التعرف الصوتي نشط. اضغط إيقاف من التطبيق لإنهائه.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xEE172638.toInt())
        }
        status = TextView(this).apply {
            text = "● يستمع الآن"
            textSize = 12f
            setTextColor(0xFF8BE0B0.toInt())
        }
        transcript = TextView(this).apply {
            text = "تحدث بالعربية..."
            textSize = 17f
            setTextColor(Color.WHITE)
            textDirection = TextView.TEXT_DIRECTION_RTL
            maxLines = 5
        }
        val close = TextView(this).apply {
            text = "إخفاء النافذة"
            textSize = 12f
            setTextColor(0xFFFFD28A.toInt())
            setPadding(0, 12, 0, 0)
            setOnClickListener { removeOverlay() }
        }
        panel.addView(status); panel.addView(transcript); panel.addView(close)
        overlay = panel
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = 48 }
        try { windowManager?.addView(panel, params) } catch (_: Exception) {}
    }

    private fun removeOverlay() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        overlay = null
    }

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status?.post { status?.text = "لا يوجد محرك تعرف صوتي متاح" }
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(this)
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-IQ")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            status?.post { status?.text = "تعذر بدء التعرف الصوتي" }
        }
    }

    private fun scheduleRestart() {
        if (restarting) return
        restarting = true
        // SpeechRecognizer implementations often end a recognition session.
        // Restart is event-driven; Android may still impose provider/session limits.
        transcript?.postDelayed({
            restarting = false
            if (overlay != null || transcript != null) startRecognition()
        }, 450)
    }

    override fun onReadyForSpeech(params: Bundle?) {
        status?.post { status?.text = "● يستمع الآن" }
    }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { status?.post { status?.text = "جارٍ معالجة الكلام..." } }

    override fun onResults(results: Bundle?) {
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val phrase = list?.firstOrNull()?.trim().orEmpty()
        if (phrase.isNotEmpty()) {
            finalText = (finalText + " " + phrase).trim()
            updateText(finalText)
        }
        scheduleRestart()
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val partial = list?.firstOrNull()?.trim().orEmpty()
        if (partial.isNotEmpty()) updateText((finalText + " " + partial).trim())
    }

    private fun updateText(value: String) {
        transcript?.post { transcript?.text = value }
    }

    override fun onError(error: Int) {
        status?.post { status?.text = "إعادة الاتصال بمحرك التعرف..." }
        scheduleRestart()
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        removeOverlay()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
